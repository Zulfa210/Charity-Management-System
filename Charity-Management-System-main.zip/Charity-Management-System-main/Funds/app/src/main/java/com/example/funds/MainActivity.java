package com.example.funds;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;

import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button button;
    private Button button2;
    private Button button3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = (Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openactivity_donor_sign_in();

            }
        });
        button2 = (Button) findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openactivity_reciever_sign_in();
            }
        });
    }
    public void openactivity_donor_sign_in(){
        Intent intent = new Intent(MainActivity.this,DonorSignIn.class);
        startActivity(intent);
    }
    public void openactivity_reciever_sign_in(){
        Intent intent = new Intent(MainActivity.this,recieverSignIn.class)
    }
}